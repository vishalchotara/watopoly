#ifndef _NONPROPERTY_
#define _NONPROPERTY_

#include <string>
#include "square.h"

class NonProperty : public Square {

public:
	NonProperty(std::string n);
};

#endif
