#include "osap.h"

OSAP::OSAP() : NonProperty("Collect OSAP") {}

void OSAP::playerEffect(std::shared_ptr<Player>) {
}
