#include "nonproperty.h"

NonProperty::NonProperty(std::string n) : Square(n) {}

